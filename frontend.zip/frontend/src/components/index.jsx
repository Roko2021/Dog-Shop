import Signup from './Signup';
import Login from './Login';
import Profile from './profile';
import ForgetPassword from './ForgetPassword';
import VerifyEmail from './VerifyEmail';



export {
    Signup,
    Login,
    Profile,
    ForgetPassword,
    VerifyEmail
}